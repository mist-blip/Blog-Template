<?php

 $name = $_POST['name'];
 $email = $_POST['email'];

 //Database Connection
 $conn = new mysqli('localhost','root','','contactme_info');
 if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
 }else{
    $stmt = $conn->prepare("insert into contactdetails(name, email)values(?, ?)");
    $stmt->bind_param("ss",$name,$email);
    $stmt->execute();
    echo "contact info sent successfully...";
    $stmt->close();
    $stmt->close();

 }
?>